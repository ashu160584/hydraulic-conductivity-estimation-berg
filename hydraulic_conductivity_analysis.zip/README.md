# hydraulic_conductivity_analysis

This project estimates and visualizes hydraulic conductivity (K) using groundwater well data from SGU.
